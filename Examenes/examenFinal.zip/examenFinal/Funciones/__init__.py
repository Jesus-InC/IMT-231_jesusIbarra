from .divisores import divisores
from .fibonacci_inverso import fibonacci_inverso
from .primos import primos
from .triangulo_letras import triangulo_letras
